import math
import torch

mu0 = 4 * math.pi * 1e-7

RANDOM_SEED = 42
DTYPE = torch.float32
